package com.example.postmodservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostModServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
