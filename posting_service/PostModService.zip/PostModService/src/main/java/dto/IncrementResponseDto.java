package dto;
public class IncrementResponseDto {
    private boolean success;
    private int count;
    private int removedPostsCount; // New field for the count of removed posts
    private String userId; // Field to associate the user with the count

    public IncrementResponseDto(boolean success, int removedPostsCount, String userId) {
        this.success = success;
        this.removedPostsCount = removedPostsCount;
        this.userId = userId;
    }

    public IncrementResponseDto() {
    }

    public boolean isSuccess() {
        return success;
    }

    public int getCount() {
        return count;
    }

    public int getRemovedPostsCount(String userId) {
        return removedPostsCount;
    }

    public String getUserId() {
        return userId;
    }

    // Optionally, you can add a setter for userId and removedPostsCount if needed
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setRemovedPostsCount(int removedPostsCount,String userId) {
        this.removedPostsCount = removedPostsCount;
    }
    public int findCountById(String userId) {
        if (this.userId.equals(userId)) {
            return removedPostsCount;
        } else {
            // Handle the case when the userIds do not match
            // This might be returning a default value or throwing an exception
            return 0; // or throw new IllegalArgumentException("User ID does not match.");
        }
    }
}
