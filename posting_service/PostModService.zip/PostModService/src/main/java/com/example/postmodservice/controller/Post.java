package com.example.postmodservice.controller;

import java.util.Date;
import java.util.UUID;
public class Post {
    private String id;
    private String userId;
    private String content;
    private Date creationDate;

    public Post() {
        // Generate a unique identifier for this post
        this.id = UUID.randomUUID().toString();
        this.creationDate = new Date();
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    // No setter for creationDate since it's set in the constructor
}
