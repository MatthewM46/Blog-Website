package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import dto.PostRequestDto;
import dto.PostResponseDto;
import dto.CommentRequestDto;
import dto.CommentResponseDto;
import dto.ReviewRequestDto;
import dto.ReviewResponseDto;
import dto.IncrementResponseDto;
import dto.ReviewPostResponseDto;
import dto.PostCreateRequest;
import dto.CommentCreateRequest;
import com.example.postmodservice.controller.Comment;
import com.example.postmodservice.controller.Post;
import service.PostService;

import java.util.List;
import java.util.Optional;


@Service
public class PostService {

    @Autowired
    private PostRepository postRepository;

    @Autowired
    private CommentRepository commentRepository;

    public Post createPost(PostCreateRequest request) {
        validateRequest(request.getUserId(), request.getContent());
        Post post = new Post();
        post.setContent(request.getContent());
        post.setUserId(request.getUserId());
        return postRepository.save(post);
    }

    public Comment createComment(String postId, CommentCreateRequest request) {
        validateRequest(request.getUserId(), request.getContent());
        Post post = postRepository.findById(postId).orElseThrow(() -> new RuntimeException("Post not found"));
        Comment comment = new Comment();
        comment.setContent(request.getContent());
        comment.setUserId(request.getUserId());
        comment.setPost(post);
        return commentRepository.save(comment);
    }

    private void validateRequest(String userId, String content) {
        if (!StringUtils.hasText(userId)) {
            throw new IllegalArgumentException("User ID cannot be blank");
        }
        if (!StringUtils.hasText(content)) {
            throw new IllegalArgumentException("Content cannot be blank");
        }
    }
    public Comment addComment(String postId, String userId, String content) {
        Comment comment = new Comment();
        comment.setPostId(postId);
        comment.setUserId(userId);
        comment.setContent(content);
        return commentRepository.save(comment);
    }

    public List<Post> getPosts() {
        return postRepository.findAll();
    }

    public Optional<Post> getPostForReview(String postId) {
        return postRepository.findById(postId);
    }

    public boolean reviewPost(String postId, String decision, String moderatorId) {
        Optional<Post> postOptional = postRepository.findById(postId);
        if (postOptional.isPresent()) {
            Post post = postOptional.get();
            // Update the post status based on the decision
            // For example, if decision is "approve", you might set a flag on the post to indicate it's approved
            postRepository.save(post);
            return true;
        }
        return false;
    }

    public int incrementRemovedPostCount(String userId) {
        // Logic to increment the count
        // This might involve retrieving a user object and updating a count field
        // For simplicity, we're just returning a dummy value here
        return 1; // Replace with actual logic
    }
}
